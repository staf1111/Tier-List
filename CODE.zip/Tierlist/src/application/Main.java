package application;

import javafx.application.Application;
import javafx.stage.Stage;
import services.api.Api;
import services.data.DataManager;
import services.data.Settings;
import services.data.Temporary;
import services.screenManager.Manager;

public class Main extends Application {
	@Override
	public void start(Stage primaryStage) {
		try {
			Settings.init();  //on initialise la classe qui va gérer les paramètre de l'application
			DataManager.init();  //on initialise la classe qui va géré la sauvegarde des donnée et l'importation des tier list ainsi que 

			Manager.init(primaryStage); //on initialise la classe qui va géré les différente page et modal
			
			Api.init();
			
			Temporary.init(); // class qui stocke de manière temporaire des donnée
				
			
			primaryStage.setTitle("Tierlist");
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
